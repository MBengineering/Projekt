var searchData=
[
  ['backlight_5foff',['BACKLIGHT_OFF',['../_l_c_d_8h.html#a0f50ae3b4bdb42dd5ad74b2c604a7515',1,'LCD.h']]],
  ['backlight_5fon',['BACKLIGHT_ON',['../_l_c_d_8h.html#aa5bad1c51f5fac029f3deacfef48c54b',1,'LCD.h']]]
];
