var searchData=
[
  ['autoscroll',['autoscroll',['../class_l_c_d.html#a64203ced3c4b406ee07cac9fa17e798e',1,'LCD']]]
];
