var searchData=
[
  ['write',['write',['../class_l_c_d.html#ac0b8521df860c1ec2d0c9e7a86ef48ed',1,'LCD']]]
];
