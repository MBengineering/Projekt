var searchData=
[
  ['negative',['NEGATIVE',['../_l_c_d_8h.html#aeeef728bf4726268aa5e99391a1502bca62d66a51fa7574c652597716f7709865',1,'LCD.h']]]
];
