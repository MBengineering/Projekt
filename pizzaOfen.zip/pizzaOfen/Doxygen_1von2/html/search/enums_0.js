var searchData=
[
  ['t_5fbacklighpol',['t_backlighPol',['../_l_c_d_8h.html#aeeef728bf4726268aa5e99391a1502bc',1,'LCD.h']]]
];
