var searchData=
[
  ['zeitstempel',['zeitStempel',['../encoder__init_8cpp.html#a14a3473a308a87fe96474b4852a58791',1,'zeitStempel():&#160;encoder_init.cpp'],['../encoder__taster_8cpp.html#a5f3b8abe5f737bf2996764bbdb791013',1,'zeitStempel():&#160;encoder_init.cpp']]]
];
