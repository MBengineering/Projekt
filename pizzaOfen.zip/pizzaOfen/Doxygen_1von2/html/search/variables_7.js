var searchData=
[
  ['tempsens',['tempSens',['../pizza_ofen_8ino.html#ad0e92a4159e05682a7e6fd0b6c69ebe1',1,'pizzaOfen.ino']]]
];
