var searchData=
[
  ['ofeninit',['ofenInit',['../ofen__init_8cpp.html#a0cd96fadf7f5ef1031a7d6f4dcd358ed',1,'ofenInit():&#160;ofen_init.cpp'],['../ofen__init_8h.html#a0cd96fadf7f5ef1031a7d6f4dcd358ed',1,'ofenInit():&#160;ofen_init.cpp']]],
  ['off',['off',['../class_l_c_d.html#ad2e7d0b1ea3a9e679cc6cab4e018453d',1,'LCD']]],
  ['on',['on',['../class_l_c_d.html#afcd69e5a35fbfadf4e623b53b11c178f',1,'LCD']]]
];
