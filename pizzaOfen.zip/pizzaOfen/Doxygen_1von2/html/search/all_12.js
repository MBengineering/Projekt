var searchData=
[
  ['zeitstempel',['zeitStempel',['../encoder__init_8cpp.html#acf27b5ff55fc3f16e21463d9a746c055',1,'zeitStempel():&#160;encoder_init.cpp'],['../encoder__taster_8cpp.html#a14a3473a308a87fe96474b4852a58791',1,'zeitStempel():&#160;encoder_init.cpp']]]
];
