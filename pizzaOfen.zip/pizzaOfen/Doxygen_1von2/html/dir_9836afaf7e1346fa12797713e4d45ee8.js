var dir_9836afaf7e1346fa12797713e4d45ee8 =
[
    [ "GitHub", "dir_678450261be458195fd8b8bf7ad4afd4.html", "dir_678450261be458195fd8b8bf7ad4afd4" ]
];