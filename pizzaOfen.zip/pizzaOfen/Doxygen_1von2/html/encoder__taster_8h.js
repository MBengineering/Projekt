var encoder__taster_8h =
[
    [ "tasterPressedISR", "encoder__taster_8h.html#af5fea2a2ccdb8d02b6dae0ea90a48219", null ]
];