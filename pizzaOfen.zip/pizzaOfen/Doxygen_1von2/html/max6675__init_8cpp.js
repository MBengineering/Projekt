var max6675__init_8cpp =
[
    [ "thermoCLK", "max6675__init_8cpp.html#a5c61dba704997faadb48d36620903a3a", null ],
    [ "thermoCS", "max6675__init_8cpp.html#a6eca0c37af8c851ddc450dd7475c8d2c", null ],
    [ "thermoDO", "max6675__init_8cpp.html#aabad0bf6211c2451ae9e3670c66726b9", null ],
    [ "thermocouple", "max6675__init_8cpp.html#a40737f10a37af8bf76892aab1ca55dad", null ]
];