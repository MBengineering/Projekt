var class_m_a_x6675 =
[
    [ "MAX6675", "class_m_a_x6675.html#a47cd2f2070b4f1e540406e37017eb994", null ],
    [ "readCelsius", "class_m_a_x6675.html#a2a630714b830f242a260a4357a85c0ab", null ],
    [ "readFahrenheit", "class_m_a_x6675.html#acbb176e33815dc3f980d22dcd398a1ea", null ],
    [ "readFarenheit", "class_m_a_x6675.html#abb38af48eca7cacc0d3a5f338d213a83", null ]
];