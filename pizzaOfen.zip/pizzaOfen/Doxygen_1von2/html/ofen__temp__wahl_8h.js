var ofen__temp__wahl_8h =
[
    [ "Sollwert", "ofen__temp__wahl_8h.html#ad26325846c3fa1256f4b5ae38efc3ba1", null ]
];